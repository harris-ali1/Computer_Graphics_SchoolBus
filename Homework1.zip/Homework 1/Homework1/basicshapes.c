// Adnan, Harris
// Homework 1 Fall 2023

//basicshapes.c


#include <GL/glut.h>         /* glut.h includes gl.h and glu.h*/

void drawScene(void)
{
    glClear(GL_COLOR_BUFFER_BIT);

    // Draw the triangle 
    glBegin(GL_TRIANGLES);
    glVertex2f(0.25, 0);
    glVertex2f(0.75, 0);
    glVertex2f(0.5, 0.5);
    glEnd();

    // Draw the trapezoid 
    glBegin(GL_QUADS);
    glVertex2f(-0.75, -0.75);
    glVertex2f(-0.25, -0.75);
    glVertex2f(-0.33, -0.25);
    glVertex2f(-0.67, -0.25);
    glEnd();

    glFlush();
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(0, 0);
    glutCreateWindow("basic shapes");
    glutDisplayFunc(drawScene);
    glutMainLoop();
}


