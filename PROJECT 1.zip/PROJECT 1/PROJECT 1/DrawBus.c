//Adnan, Harris
//Project 1


#include <stdlib.h>
#include <GL/glut.h>
#include <math.h>

static GLfloat spin = 0.0;

void drawCylinder(GLfloat radius, GLfloat height, GLint slices) {
    GLUquadric* quad = gluNewQuadric();
    gluCylinder(quad, radius, radius, height, slices, 1);
    gluDeleteQuadric(quad);
}

void drawDisk(GLfloat inner, GLfloat outer, GLfloat slices, GLfloat rings) {
    GLUquadric* quad = gluNewQuadric();
    gluDisk(quad, inner, outer, slices, rings);
    gluDeleteQuadric(quad);
}

// Function to draw the bus
void drawBus() {
    // Draw the body of the bus (cube-like shape)
    glColor3f(1.0, 1.0, 0.0); // Yellow color
    glPushMatrix();
    glTranslatef(0.0, 0.0, 0); // Move the bus down a bit
    glScalef(2.0, 0.6, 0.6); // Stretch the cube to make it look like a bus
    glutSolidCube(1.0);
    glPopMatrix();


    // Disable depth testing for the windows (temporarily)
    //glDisable(GL_DEPTH_TEST);

    // Attach the second cube to the front of the bus
    glColor3f(1.0, 1.0, 0.0); // Yellow color
    glPushMatrix();
    glTranslatef(1.0, -0.12, 0); // Adjust the position relative to the bus
    glScalef(0.5, 0.35, 0.58); // Adjust the size of the second cube
    glutSolidCube(1.0);
    glPopMatrix();

    // Draw the rectangular windscreen in blue color
    glColor3f(0.0, 1.0, 1.0); // Blue color for the windscreen
    glPushMatrix();
    glTranslatef(1.001, 0.15, 0); // Adjust the position to be just above the second cube
    glRotatef(90.0, 0.0, 1.0, 0.0); // Rotate the polygon horizontally (around the Y-axis)
    glScalef(0.6, 0.2, 0.1); // Scale down the polygon to fit above the second cube and shape it like a rectangle

    // Define the vertices for the rectangular windscreen
    glBegin(GL_POLYGON);
    glVertex3f(-0.5, 0.5, 0);   // Top-left vertex
    glVertex3f(0.5, 0.5, 0);    // Top-right vertex
    glVertex3f(0.5, -0.5, 0);   // Bottom-right vertex
    glVertex3f(-0.5, -0.5, 0);  // Bottom-left vertex
    glEnd();

    glPopMatrix();

    // Draw the rectangular rear window in blue color
    glColor3f(0.0, 1.0, 1.0); // Blue color for the windscreen
    glPushMatrix();
    glTranslatef(-1.001, 0.15, 0); // Adjust the position to be just above the second cube
    glRotatef(90.0, 0.0, 1.0, 0.0); // Rotate the polygon horizontally (around the Y-axis)
    glScalef(0.6, 0.2, 0.1); // Scale down the polygon to fit above the second cube and shape it like a rectangle

    // Define the vertices for the rectangular windscreen
    glBegin(GL_POLYGON);
    glVertex3f(-0.5, 0.5, 0);   // Top-left vertex
    glVertex3f(0.5, 0.5, 0);    // Top-right vertex
    glVertex3f(0.5, -1, 0);   // Bottom-right vertex
    glVertex3f(-0.5, -1, 0);  // Bottom-left vertex
    glEnd();

    glPopMatrix();

    // Disable depth testing for the windows (temporarily)
    //glDisable(GL_DEPTH_TEST);

    // Draw the windows (rectangles) in blue color
    glColor3f(0.0, 1.0, 1.0); // Blue color for windows

    // Left window
    glPushMatrix(); // Save the current modelview matrix
    glTranslatef(1.1, -0.13, 0.0499); // Translate the left window to the left
    glBegin(GL_QUADS);
    glVertex3f(-2.1, 0.38, -0.35); // Top-left corner (reduced height and increased length)
    glVertex3f(-0.1, 0.38, -0.35); // Top-right corner (reduced height and increased length)
    glVertex3f(-0.1, 0.1, -0.35); // Bottom-right corner (no change in height)
    glVertex3f(-2.1, 0.1, -0.35); // Bottom-left corner (no change in height)
    glEnd();
    glPopMatrix();

    // Right window (translated to the other side)
    glPushMatrix(); // Save the current modelview matrix
    glTranslatef(-1.1, -0.13, 0.6519); // Translate the right window to the left
    glBegin(GL_QUADS);
    glVertex3f(2.1, 0.38, -0.35); // Top-left corner (reduced height and increased length)
    glVertex3f(0.1, 0.38, -0.35); // Top-right corner (reduced height and increased length)
    glVertex3f(0.1, 0.1, -0.35); // Bottom-right corner (no change in height)
    glVertex3f(2.1, 0.1, -0.35); // Bottom-left corner (no change in height)
    glEnd();
    glPopMatrix(); // Restore the previous modelview matrix

      // Enable depth testing again
    glEnable(GL_DEPTH_TEST);

    // Draw the left headlight as a small sphere
    glColor3f(1.0, 1.0, 1.0); // White color for headlights
    glPushMatrix();
    glTranslatef(1.2, -0.15, 0.21); // Adjust the position of the left headlight
    glutSolidSphere(0.08, 20, 20); // Draw a small sphere for the headlight
    glPopMatrix();

    // Draw the right headlight as a small sphere
    glPushMatrix();
    glTranslatef(1.2, -0.15, -0.21); // Adjust the position of the right headlight
    glutSolidSphere(0.08, 20, 20); // Draw a small sphere for the headlight
    glPopMatrix();

    // Draw the left rear light as a small red sphere
    glColor3f(1.0, 0.0, 0.0); // Red color for rear lights
    glPushMatrix();
    glTranslatef(-0.95, -0.15, 0.23); // Adjust the position of the left rear light
    glutSolidSphere(0.07, 20, 20); // Draw a small sphere for the rear light
    glPopMatrix();

    // Draw the right rear light as a small red sphere
    glPushMatrix();
    glTranslatef(-0.95, -0.15, -0.23); // Adjust the position of the right rear light
    glutSolidSphere(0.07, 20, 20); // Draw a small sphere for the rear light
    glPopMatrix();

    // Draw the wheels (cylinders) with larger radius
    glColor3f(0.0, 0.0, 0.0); // Black color
    const float wheelRadius = 0.15; // Increase the wheel radius
    const float wheelOffsetY = -0.3;
    const float wheelOffsetZ = 0.25; // Adjust the Z-coordinate to attach the wheels
    const float wheelHeight = 0.05;

    // Left front wheel
    glPushMatrix();
    glTranslatef(-0.8, wheelOffsetY, wheelOffsetZ);
    drawCylinder(wheelRadius, wheelHeight, 20);
    glPopMatrix();

    // Left front wheel hub cap disks.
    glPushMatrix();
    glTranslatef(-0.8, wheelOffsetY, wheelOffsetZ);
    drawDisk(0, wheelRadius, 20, 1);
    glPopMatrix();

    // Right front wheel
    glPushMatrix();
    glTranslatef(0.8, wheelOffsetY, wheelOffsetZ);
    drawCylinder(wheelRadius, wheelHeight, 20);
    glPopMatrix();

    // Right front wheel hub cap disks.
    glPushMatrix();
    glTranslatef(0.8, wheelOffsetY, wheelOffsetZ);
    drawDisk(0, wheelRadius, 20, 1);
    glPopMatrix();

    // Left rear wheel
    glPushMatrix();
    glTranslatef(-0.8, wheelOffsetY, -wheelOffsetZ); // Opposite side
    drawCylinder(wheelRadius, wheelHeight, 20);
    glPopMatrix();

    // left rear wheel hub cap disks
    glPushMatrix();
    glTranslatef(-0.8, wheelOffsetY, -wheelOffsetZ - .001);
    drawDisk(0, wheelRadius, 20, 1);
    glPopMatrix();

    // Right rear wheel
    glPushMatrix();
    glTranslatef(0.8, wheelOffsetY, -wheelOffsetZ); // Opposite side
    drawCylinder(wheelRadius, wheelHeight, 20);
    glPopMatrix();

    // Right rear wheel hub cap disks
    glPushMatrix();
    glTranslatef(0.8, wheelOffsetY, -wheelOffsetZ);
    drawDisk(0, wheelRadius, 20, 1);
    glPopMatrix();

    // Draw the air curtain in front of the bus
    glColor3f(0.5, 0.5, 0.5); // Blue color for the air curtain
    glPushMatrix();
    glTranslatef(1.27, -0.16, 0.0); // Position the air curtain in front of the bus

    // Define the vertices for the front air curtain as a smaller polygon
    glBegin(GL_POLYGON);
    glVertex3f(0.0, 0.06, 0.11); // Top-right
    glVertex3f(0.0, -0.06, 0.11); // Bottom-right
    glVertex3f(0.0, -0.06, -0.11); // Bottom-left
    glVertex3f(0.0, 0.06, -0.11); // Top-left
    glEnd();

    glPopMatrix();

    // Draw the air curtain at the back of the bus
    glColor3f(0.5, 0.5, 0.5); // Blue color for the air curtain
    glPushMatrix();
    glTranslatef(-1.01, -0.16, 0.0); // Position the air curtain at the back of the bus

    // Define the vertices for the back air curtain as a small rectangle
    glBegin(GL_POLYGON);
    glVertex3f(0.0, 0.06, 0.15); // Top-right
    glVertex3f(0.0, -0.06, 0.15); // Bottom-right
    glVertex3f(0.0, -0.06, -0.15); // Bottom-left
    glVertex3f(0.0, 0.06, -0.15); // Top-left
    glEnd();

    glPopMatrix();
}


void idle() {
    spin += 0.5;
    if (spin > 360.0) {
        spin -= 360.0;
    }
    glutPostRedisplay();
}

void mouse(int btn, int state, int x, int y) {
    if (btn == GLUT_LEFT_BUTTON && state == GLUT_DOWN) glutIdleFunc(idle);
    if (btn == GLUT_MIDDLE_BUTTON && state == GLUT_DOWN) glutIdleFunc(NULL);
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();


    gluPerspective(60, 1.33, 0.1, 10);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(2.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);

    glRotatef(spin, 0.0, 1.0, 0.0);
    drawBus();

    glFlush();
    glutSwapBuffers();
}

void myReshape(int w, int h)
{
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    // for orthographic projection, as long as the object is inside the viewing box, 
     // it does NOT MATTER how long the viewing box is by varying the near and far
    if (w <= h)
        glOrtho(-2.0, 2.0, -2.0 * (GLfloat)h / (GLfloat)w,
            2.0 * (GLfloat)h / (GLfloat)w, -10.0, 10.0);
    else
        glOrtho(-1.0 * (GLfloat)w / (GLfloat)h,
            1.5 * (GLfloat)w / (GLfloat)h, -0.8, 0.8, -5.0, 5.0);
    glMatrixMode(GL_MODELVIEW);
    glutPostRedisplay();
}


int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Adnan Harris Bus Version 1");

    glClearColor(1.0, 1.0, 1.0, 1.0);
    glEnable(GL_DEPTH_TEST);

    glutDisplayFunc(display);
    glutReshapeFunc(myReshape);
    glutIdleFunc(idle);
    glutMouseFunc(mouse);
    glutMainLoop();

    return 0;
}
