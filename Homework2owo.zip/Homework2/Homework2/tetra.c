// Your Last, First Name
// Homework 2 Fall 2023

/* tetra.c */

#include <stdlib.h>
#ifdef __APPLE_
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

typedef float vertex[3];

/* initial tetrahedron */
vertex vertices[] = {
         {0.0,        0.0,       1.0},
           {0.0,        0.942809, -0.33333},
           {-0.816497, -0.471405, -0.333333},
           {0.816497,  -0.471405, -0.333333} };

static GLfloat theta[] = { 0.0,0.0,0.0 };

/* display one triangle using a line loop for wire frame, a single
normal for constant shading, or three normals for interpolative shading */
void triangle(int a, int b, int c)
{
    glBegin(GL_POLYGON);
    glNormal3fv(vertices[a]);

    glVertex3fv(vertices[a]);
    glVertex3fv(vertices[b]);
    glVertex3fv(vertices[c]);
    glEnd();
}

void tetrahedron()
{
    /*  Faces of tetrahedron */
    glColor3f(1.0, 0.0, 0.0);   // red
    triangle(0, 1, 2);

    glColor3f(0.0, 1.0, 0.0);   // green
    triangle(3, 2, 1);

    glColor3f(0.0, 0.0, 1.0);   // blue
    triangle(0, 3, 1);

    glColor3f(0.0, 0.0, 0.0);   // black
    triangle(0, 2, 3);
}

void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    tetrahedron();
    glFlush();
}


void myReshape(int w, int h)
{
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    if (w <= h)
        glOrtho(-2.0, 2.0, -2.0 * (GLfloat)h / (GLfloat)w,
            2.0 * (GLfloat)h / (GLfloat)w, -10.0, 10.0);
    else
        glOrtho(-2.0 * (GLfloat)w / (GLfloat)h,
            2.0 * (GLfloat)w / (GLfloat)h, -2.0, 2.0, -10.0, 10.0);
    glMatrixMode(GL_MODELVIEW);
    glutPostRedisplay();
}

void  main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(500, 500);
    glutCreateWindow("tetrahedron");
    glutReshapeFunc(myReshape);
    glutDisplayFunc(display);
    glEnable(GL_DEPTH_TEST);
    glClearColor(1.0, 1.0, 1.0, 1.0);
    glutMainLoop();
}
