﻿// Adnan, Harris
// Homework 3 Fall 2023

// House2.cs

using System;
using Tao.FreeGlut;
using Tao.OpenGl;
using Tao.Platform;

namespace House_2
{
    /// <summary>
    /// Summary description for Class1.
    /// </summary>
    class house_2
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        /// 

        private const int KEY_ESC = 27;	/* ascii value for the escape key */
        private const int TRUE = 1;
        private const int FALSE = 0;
        private const int MOVE_EYE = 0;
        private const int TWIST_EYE = 1;
        private const int ZOOM = 2;
        private const int MOVE_NONE = 3;

        /* Global Variables */

        static string progname;
        static int width, height;
        //enum		actions { MOVE_EYE, TWIST_EYE, ZOOM, MOVE_NONE };
        static int eye = TRUE, flat = FALSE;
        static int action;
        static double xStart = 0.0, yStart = 0.0;
        static float nearClip, farClip, distance, twistAngle, incAngle, azimAngle;

        static float[][] vertices = new float[][]{
            new float[]{-1.0f,-1.0f,-1.0f},  // vertex 0
            new float[]{1.0f,-1.0f,-1.0f},
            new float[]{1.0f,1.0f,-1.0f},
            new float[]{-1.0f,1.0f,-1.0f},
            new float[]{-1.0f,-1.0f,1.0f},
            new float[]{1.0f,-1.0f,1.0f},   // vertex 5
            new float[]{1.0f,1.0f,1.0f},
            new float[]{-1.0f,1.0f,1.0f},
            new float[]{1.0f,-1.0f,0.3f},
            new float[]{1.0f,1.0f,0.3f},
            new float[]{1.0f,1.0f,-0.3f},   // vertex 10
			new float[]{1.0f,-1.0f,-0.3f},
            new float[]{1.0f,0.3f,0.3f},
            new float[]{1.0f,0.3f,-0.3f},
            new float[]{-0.3f,-1.0f,1.0f},
            new float[]{-0.3f,1.0f,1.0f},   // vertex 15
            new float[]{0.3f,1.0f,1.0f},
            new float[]{0.3f,-1.0f,1.0f},
            new float[]{-0.3f,0.5f,1.0f},
            new float[]{0.3f,0.5f,1.0f},
            new float[]{0.3f,-0.5f,1.0f},   // vertex 20
            new float[]{-0.3f,-0.5f,1.0f}};

        static float[][] normals = new float[][]{
            new float[]{-1.0f,-1.0f,-1.0f}, // normal 0
            new float[]{1.0f,-1.0f,-1.0f},
            new float[]{1.0f,1.0f,-1.0f},
            new float[]{-1.0f,1.0f,-1.0f},
            new float[]{-1.0f,-1.0f,1.0f},
            new float[]{1.0f,-1.0f,1.0f},   // normal 5
            new float[]{1.0f,1.0f,1.0f},
            new float[]{-1.0f,1.0f,1.0f},
            new float[]{1.0f,-1.0f,0.3f},
            new float[]{1.0f,0.3f,0.3f},
            new float[]{1.0f,0.3f,-0.3f},   // normal 10
			new float[]{1.0f,-1.0f,-0.3f},
            new float[]{1.0f,0.3f,0.3f},
            new float[]{1.0f,0.3f,-0.3f},
            new float[]{-0.3f,-1.0f,1.0f},
            new float[]{-0.3f,1.0f,1.0f},   // normal 15
            new float[]{0.3f,1.0f,1.0f},
            new float[]{0.3f,-1.0f,1.0f},
            new float[]{-0.3f,0.5f,1.0f},
            new float[]{0.3f,0.5f,1.0f},
            new float[]{0.3f,-0.5f,1.0f},   // normal 20
            new float[]{-0.3f,-0.5f,1.0f}};

        static float[][] colors = new float[][]{
            new float[]{0.0f,0.0f,0.0f},     // color 0
            new float[]{1.0f,0.0f,0.0f},
            new float[]{1.0f,1.0f,0.0f},
            new float[]{0.0f,1.0f,0.0f},
            new float[]{0.0f,0.0f,1.0f},
            new float[]{1.0f,0.0f,1.0f},     // color 5
            new float[]{1.0f,1.0f,1.0f},
            new float[]{0.0f,1.0f,1.0f},
            new float[]{1.0f,0.5f,0.0f},
            new float[]{1.0f,0.5f,0.0f},
            new float[]{1.0f,0.5f,0.0f},     // color 10
			new float[]{1.0f,0.5f,0.0f},
            new float[]{1.0f,0.5f,0.0f},
            new float[]{1.0f,0.5f,0.0f},
            new float[]{1.0f,1.0f,1.0f},
            new float[]{1.0f,1.0f,1.0f},     // color 15
            new float[]{1.0f,1.0f,1.0f},
            new float[]{1.0f,1.0f,1.0f},
            new float[]{1.0f,1.0f,1.0f},
            new float[]{1.0f,1.0f,1.0f},
            new float[]{1.0f,1.0f,1.0f},     // color 20
            new float[]{1.0f,1.0f,1.0f}};

        [STAThread]
        static void Main(string[] args)
        {
            Glut.glutInit();
            /* create a window that is 1/4 the size of the screen,
             * and position it in the middle of the screen.
             */
            width = Glut.glutGet(Glut.GLUT_SCREEN_WIDTH);
            height = Glut.glutGet(Glut.GLUT_SCREEN_HEIGHT);
            Glut.glutInitWindowPosition(width / 4, height / 4);
            Glut.glutInitWindowSize(width / 2, height / 2);
            Glut.glutInitDisplayMode(Glut.GLUT_RGBA | Glut.GLUT_DEPTH | Glut.GLUT_DOUBLE);
            Glut.glutCreateWindow("House 2");
            Glut.glutReshapeFunc(new Glut.ReshapeCallback(reshape));
            Glut.glutKeyboardFunc(new Glut.KeyboardCallback(keyboard));
            Glut.glutSpecialFunc(new Glut.SpecialCallback(specialkeys));
            Glut.glutMouseFunc(new Glut.MouseCallback(mouse));
            Glut.glutMotionFunc(new Glut.MotionCallback(motion));
            Glut.glutDisplayFunc(new Glut.DisplayCallback(drawScene));

            progname = "House 2";
            printHelp(progname);
            initgfx();
            Glut.glutMainLoop();
        }

        /*  Moving around in space  
         *	Left Mouse Button, eye=true	 - change incidence and azimuth angles
         *	Left Mouse Button, eye=false - change the twist angle based on
         *				  horizontal mouse movement
         *	Right Mouse Button	- zoom in and out based on vertical
         *				  mouse movement
         *	<R> Key			- reset viewpoint
         *   'e'            - toggle "eye" off/on
         *	Escape Key		- exit program
         */


        public static void printHelp(string progn)
        {
            /*fprintf(stdout, "\n%s - Move around in space\n\n"
             "F1 key		- print help information\n"
             "Left Mousebutton	- move eye position\n"
             "Middle Mousebutton	- change twist angle\n"
             "Right Mousebutton	- move up / down to zoom in / out\n"
             "<R> Key		- reset viewpoint\n"
             "Escape Key	- exit the program\n\n", progn);*/

            Console.WriteLine("Move around in space");
            Console.WriteLine("F1 key		- print help information");
            Console.WriteLine("Left Mousebutton	- move eye position");
            Console.WriteLine("Middle Mousebutton	- change twist angle");
            Console.WriteLine("Right Mousebutton	- move up / down to zoom in / out");
            Console.WriteLine("<R> Key		- reset viewpoint");
            Console.WriteLine("Escape Key	- exit the program" + progn);
        }

        public static void initgfx()
        {
            /* set clear color to black */
            Gl.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

            /* enable the depth buffer */
            Gl.glEnable(Gl.GL_DEPTH_TEST);

            nearClip = 1.0f;
            farClip = nearClip + 10.0f;

            resetView();
        }

        public static void reshape(int width, int height)
        {
            double aspect;

            Gl.glViewport(0, 0, width, height);

            /* compute aspect ratio */
            aspect = (double)width / (double)height;
            if (height > width) aspect = 1.0f;
            Gl.glMatrixMode(Gl.GL_PROJECTION);

            /* Reset world coordinates first ... */
            Gl.glLoadIdentity();

            /* Reset the viewing volume based on the new aspect ratio */
            Glu.gluPerspective(45.0f, aspect, nearClip, farClip);

            Gl.glMatrixMode(Gl.GL_MODELVIEW);
        }


        public static void keyboard(byte key, int x, int y)
        {
            switch (key)
            {
                case (byte)'e':
                    if (eye == 0)
                        eye = 1;
                    else
                        eye = 0;
                    break;
                case (byte)'z':
                    eye = 2;
                    break;
                case (byte)' ':	/* SPACE key */
                    /* generate a random background color */
                    Random r = new Random();
                    Gl.glClearColor((float)(r.Next(0, 32768) / 32768.0), (float)(r.Next(0, 32768) / 32768.0),
                        (float)(r.Next(0, 32768) / 32768.0), 1.0f);
                    Glut.glutPostRedisplay();
                    break;
                case (byte)'s':	/* s key */
                    /* toggle between smooth and flat shading */
                    if (flat == 0)
                        flat = 1;
                    else
                        flat = 0;
                    if (flat == 1)
                        Gl.glShadeModel(Gl.GL_FLAT);
                    else
                        Gl.glShadeModel(Gl.GL_SMOOTH);
                    Glut.glutPostRedisplay();
                    break;
                case (byte)'R':
                    resetView();
                    Glut.glutPostRedisplay();
                    break;
                case (byte)KEY_ESC:	/* Exit when the Escape key is pressed */
                    Environment.Exit(0);
                    break;
            }
        }

        public static void specialkeys(int key, int x, int y)
        {
            switch (key)
            {
                case Glut.GLUT_KEY_F1:	/* Function key #1 */
                    /* print help information */
                    printHelp(progname);
                    break;
            }
        }

        public static void mouse(int button, int state, int x, int y)
        {
            if (state == Glut.GLUT_DOWN)
            {
                switch (button)
                {
                    case Glut.GLUT_LEFT_BUTTON:
                        if (eye == 0) action = TWIST_EYE;
                        if (eye == 1) action = MOVE_EYE;
                        if (eye == 2) action = ZOOM;

                        break;
                    case Glut.GLUT_RIGHT_BUTTON:
                        action = ZOOM;
                        break;
                    default:
                        break;
                }

                /* Update the saved mouse position */
                xStart = x;
                yStart = y;
            }
            else
            {
                action = MOVE_NONE;
            }

        }

        public static void motion(int x, int y)
        {
            switch (action)
            {
                case MOVE_EYE:
                    /* Adjust the eye position based on the mouse position */
                    azimAngle += (float)(x - xStart);
                    incAngle -= (float)(y - yStart);
                    break;
                case TWIST_EYE:
                    /* Adjust the eye twist based on the mouse position */
                    //twistAngle = mod(twistAngle+(x - xStart), 360.0);
                    twistAngle = (float)(twistAngle + (x - xStart) % 360.0);
                    break;
                case ZOOM:
                    /* Adjust the eye distance based on the mouse position */
                    distance -= (float)(10.0 * (y - yStart) / width);
                    break;
                default:
                    break;
            }

            /* Update the stored mouse position for later use */
            xStart = x;
            yStart = y;

            Glut.glutPostRedisplay();
        }

        public static void resetView()
        {
            distance = (float)nearClip + (float)((farClip - nearClip) / 2.0);
            twistAngle = 0.0f;	/* rotation of viewing volume (camera) */
            incAngle = 0.0f;
            azimAngle = 0.0f;
        }

        public static void flythru1(float distance, float azimuth, float incidence,
            float twist)
        {
            Gl.glTranslatef(0.0f, 0.0f, -distance);
            Gl.glRotatef(-twist, 0.0f, 0.0f, 1.0f);
            Gl.glRotatef(-incidence, 1.0f, 0.0f, 0.0f);
            Gl.glRotatef(-azimuth, 0.0f, 1.0f, 0.0f);
        }


        public static void drawScene()
        {

            Gl.glClear(Gl.GL_COLOR_BUFFER_BIT | Gl.GL_DEPTH_BUFFER_BIT);

            Gl.glPushMatrix();

            /* set up viewing transformation */
            flythru1(distance, azimAngle, incAngle, twistAngle);


            /* draw cube */
            colorcube();

            Gl.glPopMatrix();

            Glut.glutSwapBuffers();
        }



        public static void colorcube()
        {
            /* map vertices to faces */
            Gl.glTranslatef(-1.0f, 0.0f, 0.0f);
            // back
            polygon(3, 2, 1, 0);
            // top
            polygon(2, 3, 7, 6);
            //left
            polygon(4, 7, 3, 0);
            //right with door
            polygon(11, 1, 2, 10);
            polygon(9, 6, 5, 8);
            polygon(9, 12, 13, 10);
            //front with window;
            polygon(15, 7, 4, 14);
            polygon(6, 16, 17, 5);
            polygon(16, 15, 18, 19);
            polygon(20, 21, 14, 17);
            //floor
            polygon(5, 4, 0, 1);

            Gl.glTranslatef(2.0f, 0.0f, 0.0f);
            // back
            polygon(3, 2, 1, 0);
            // top
            polygon(2, 3, 7, 6);
            //left side not drawn
            //polygon(4,7,3,0);
            //right with door
            polygon(11, 1, 2, 10);
            polygon(9, 6, 5, 8);
            polygon(9, 12, 13, 10);
            //front with window;
            polygon(15, 7, 4, 14);
            polygon(6, 16, 17, 5);
            polygon(16, 15, 18, 19);
            polygon(20, 21, 14, 17);
            //floor
            polygon(5, 4, 0, 1);

        }

        public static void polygon(int a, int b, int c, int d)
        {
            /* draw a polygon via list of vertices */

            Gl.glBegin(Gl.GL_POLYGON);
            Gl.glColor3fv(colors[a]);
            Gl.glNormal3fv(normals[a]);
            Gl.glVertex3fv(vertices[a]);

            Gl.glColor3fv(colors[b]);
            Gl.glNormal3fv(normals[b]);
            Gl.glVertex3fv(vertices[b]);

            Gl.glColor3fv(colors[c]);
            Gl.glNormal3fv(normals[c]);
            Gl.glVertex3fv(vertices[c]);

            Gl.glColor3fv(colors[d]);
            Gl.glNormal3fv(normals[d]);
            Gl.glVertex3fv(vertices[d]);
            Gl.glEnd();
        }
    }
}

